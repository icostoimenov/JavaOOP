package spaceStation.models.astronauts;

public class Geodesist extends BaseAstronaut {

    public Geodesist(String name) {
        super(name, 50.0);
    }

    @Override
    public void breath() {
        super.breath();
        super.breath();
    }
}
