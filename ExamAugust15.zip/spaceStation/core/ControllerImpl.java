package spaceStation.core;

import spaceStation.common.ConstantMessages;
import spaceStation.common.ExceptionMessages;
import spaceStation.models.astronauts.*;
import spaceStation.models.mission.Mission;
import spaceStation.models.mission.MissionImpl;
import spaceStation.models.planets.PlanetImpl;
import spaceStation.repositories.AstronautRepository;
import spaceStation.repositories.PlanetRepository;

import java.util.ArrayList;
import java.util.List;

public class ControllerImpl implements Controller {
    private AstronautRepository astronautRepository;
    private PlanetRepository planetRepository;
    private int explored;

    public ControllerImpl() {
        this.astronautRepository = new AstronautRepository();
        this.planetRepository = new PlanetRepository();
    }

    @Override
    public String addAstronaut(String type, String astronautName) {
        if (type.equals("Biologist")) {
            Biologist astronaut = new Biologist(astronautName);
            this.astronautRepository.add(astronaut);
        } else if (type.equals("Geodesist")) {
            Geodesist astronaut = new Geodesist(astronautName);
            this.astronautRepository.add(astronaut);
        } else if (type.equals("Meteorologist")) {
            Meteorologist astronaut = new Meteorologist(astronautName);
            this.astronautRepository.add(astronaut);
        } else {
            throw new IllegalArgumentException(ExceptionMessages.ASTRONAUT_INVALID_TYPE);
        }
        return String.format(ConstantMessages.ASTRONAUT_ADDED, type, astronautName);
    }

    @Override
    public String addPlanet(String planetName, String... items) {
        planetRepository.add(new PlanetImpl(planetName));
        for (String item : items) {
            planetRepository.findByName(planetName).getItems().add(item);
        }
        return String.format(ConstantMessages.PLANET_ADDED, planetName);
    }

    @Override
    public String retireAstronaut(String astronautName) {
        if (this.astronautRepository.findByName(astronautName) == null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.ASTRONAUT_DOES_NOT_EXIST, astronautName));
        }
        Astronaut astronaut = astronautRepository.findByName(astronautName);
        astronautRepository.remove(astronaut);
        return String.format(ConstantMessages.ASTRONAUT_RETIRED, astronautName);
    }

    @Override
    public String explorePlanet(String planetName) {
        List<Astronaut> suitable = new ArrayList<>();
        for (Astronaut model : this.astronautRepository.getModels()) {
            if (model.getOxygen() > 60) {
                suitable.add(model);
            }
        }
        if (suitable.isEmpty()) {
            throw new IllegalArgumentException(ExceptionMessages.PLANET_ASTRONAUTS_DOES_NOT_EXISTS);
        }
        Mission mission = new MissionImpl();
        mission.explore(this.planetRepository.findByName(planetName), suitable);
        this.explored++;
        int bodyCount = 0;
        for (Astronaut astronaut : suitable) {
            if (!astronaut.canBreath()) {
                bodyCount++;
            }
        }
        return String.format(ConstantMessages.PLANET_EXPLORED, planetName, bodyCount);
    }

    @Override
    public String report() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%d planets were explored!", explored)).append(System.lineSeparator()).append("Astronauts info:").append(System.lineSeparator());
        for (Astronaut model : this.astronautRepository.getModels()) {
            sb.append(model.toString());
            sb.append(System.lineSeparator());
        }
        return sb.toString().trim();
    }
}
